import setuptools

setuptools.setup(
    name="foo",
    version="6.9",
    packages=['my_package', 'my_package.data', 'my_package.data.transforms', 'my_package.analysis'],
    url  = '',
    license = '',
    author = 'abhinavsen2002',
    author_email = 'abhinavsen2002@gmail.com',
    description = 'Software engineering lab assignment 3, python image segmentor'

)